/* tslint:disable */
/* eslint-disable */
/**
*/
export function set_panic_hook(): void;
/**
*/
export class CoordCelestial {
  free(): void;
/**
* @param {number} ra
* @param {number} dec
*/
  constructor(ra: number, dec: number);
/**
* @returns {Point3dJs}
*/
  to_xyz(): Point3dJs;
/**
* @returns {number}
*/
  dec: number;
/**
* @returns {number}
*/
  ra: number;
}
/**
*/
export class Mtx2x2Js {
  free(): void;
/**
* @param {number} m11
* @param {number} m12
* @param {number} m21
* @param {number} m22
*/
  constructor(m11: number, m12: number, m21: number, m22: number);
}
/**
*/
export class Point2dJs {
  free(): void;
/**
* @param {number} x
* @param {number} y
*/
  constructor(x: number, y: number);
/**
* @returns {number}
*/
  x: number;
/**
* @returns {number}
*/
  y: number;
}
/**
*/
export class Point3dJs {
  free(): void;
/**
* @param {number} x
* @param {number} y
* @param {number} z
*/
  constructor(x: number, y: number, z: number);
/**
* @returns {CoordCelestial}
*/
  to_celestial(): CoordCelestial;
/**
* @returns {number}
*/
  x: number;
/**
* @returns {number}
*/
  y: number;
/**
* @returns {number}
*/
  z: number;
}
/**
*/
export class WcsTan {
  free(): void;
/**
* @param {Point2dJs} crpix
* @param {CoordCelestial} crval
* @param {Mtx2x2Js} cd
*/
  constructor(crpix: Point2dJs, crval: CoordCelestial, cd: Mtx2x2Js);
/**
* @returns {Point2dJs}
*/
  get_crpix(): Point2dJs;
/**
* @returns {CoordCelestial}
*/
  get_crval(): CoordCelestial;
/**
* @param {Float64Array} new_sip_params_x
* @param {Float64Array} new_sip_params_y
* @returns {WcsTan}
*/
  with_updated_sip(new_sip_params_x: Float64Array, new_sip_params_y: Float64Array): WcsTan;
/**
* @returns {WcsTan}
*/
  with_blank_sip(): WcsTan;
/**
* @param {Point3dJs} world
* @returns {Point2dJs | undefined}
*/
  world_2_pix(world: Point3dJs): Point2dJs | undefined;
/**
* @param {Point3dJs} world
* @returns {Point2dJs | undefined}
*/
  world_2_pix_no_sip(world: Point3dJs): Point2dJs | undefined;
/**
* @param {Point2dJs} pix
* @returns {Point3dJs}
*/
  pix_2_world(pix: Point2dJs): Point3dJs;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_coordcelestial_free: (a: number) => void;
  readonly __wbg_get_coordcelestial_ra: (a: number) => number;
  readonly __wbg_set_coordcelestial_ra: (a: number, b: number) => void;
  readonly __wbg_get_coordcelestial_dec: (a: number) => number;
  readonly __wbg_set_coordcelestial_dec: (a: number, b: number) => void;
  readonly coordcelestial_new: (a: number, b: number) => number;
  readonly coordcelestial_to_xyz: (a: number) => number;
  readonly __wbg_point3djs_free: (a: number) => void;
  readonly __wbg_get_point3djs_z: (a: number) => number;
  readonly __wbg_set_point3djs_z: (a: number, b: number) => void;
  readonly point3djs_new: (a: number, b: number, c: number) => number;
  readonly point3djs_to_celestial: (a: number) => number;
  readonly __wbg_mtx2x2js_free: (a: number) => void;
  readonly mtx2x2js_new: (a: number, b: number, c: number, d: number) => number;
  readonly __wbg_wcstan_free: (a: number) => void;
  readonly wcstan_new: (a: number, b: number, c: number) => number;
  readonly wcstan_get_crpix: (a: number) => number;
  readonly wcstan_get_crval: (a: number) => number;
  readonly wcstan_with_updated_sip: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly wcstan_with_blank_sip: (a: number) => number;
  readonly wcstan_world_2_pix: (a: number, b: number) => number;
  readonly wcstan_world_2_pix_no_sip: (a: number, b: number) => number;
  readonly wcstan_pix_2_world: (a: number, b: number) => number;
  readonly __wbg_point2djs_free: (a: number) => void;
  readonly point2djs_new: (a: number, b: number) => number;
  readonly __wbg_get_point2djs_x: (a: number) => number;
  readonly __wbg_get_point2djs_y: (a: number) => number;
  readonly __wbg_get_point3djs_x: (a: number) => number;
  readonly __wbg_get_point3djs_y: (a: number) => number;
  readonly __wbg_set_point2djs_x: (a: number, b: number) => void;
  readonly __wbg_set_point2djs_y: (a: number, b: number) => void;
  readonly __wbg_set_point3djs_x: (a: number, b: number) => void;
  readonly __wbg_set_point3djs_y: (a: number, b: number) => void;
  readonly set_panic_hook: () => void;
  readonly __wbindgen_malloc: (a: number) => number;
  readonly __wbindgen_free: (a: number, b: number) => void;
  readonly __wbindgen_realloc: (a: number, b: number, c: number) => number;
}

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
*
* @returns {Promise<InitOutput>}
*/
export default function init (module_or_path?: InitInput | Promise<InitInput>): Promise<InitOutput>;
