import * as wasm from './wcs_wasm_bg.wasm';

const heap = new Array(32).fill(undefined);

heap.push(undefined, null, true, false);

function getObject(idx) { return heap[idx]; }

let heap_next = heap.length;

function dropObject(idx) {
    if (idx < 36) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

const lTextDecoder = typeof TextDecoder === 'undefined' ? (0, module.require)('util').TextDecoder : TextDecoder;

let cachedTextDecoder = new lTextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

let cachegetUint8Memory0 = null;
function getUint8Memory0() {
    if (cachegetUint8Memory0 === null || cachegetUint8Memory0.buffer !== wasm.memory.buffer) {
        cachegetUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachegetUint8Memory0;
}

function getStringFromWasm0(ptr, len) {
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
    return instance.ptr;
}
/**
*/
export function set_panic_hook() {
    wasm.set_panic_hook();
}

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}

let WASM_VECTOR_LEN = 0;

const lTextEncoder = typeof TextEncoder === 'undefined' ? (0, module.require)('util').TextEncoder : TextEncoder;

let cachedTextEncoder = new lTextEncoder('utf-8');

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length);
        getUint8Memory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len);

    const mem = getUint8Memory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3);
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachegetInt32Memory0 = null;
function getInt32Memory0() {
    if (cachegetInt32Memory0 === null || cachegetInt32Memory0.buffer !== wasm.memory.buffer) {
        cachegetInt32Memory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachegetInt32Memory0;
}
/**
*/
export class CoordCelestial {

    toJSON() {
        return {
            ra: this.ra,
            dec: this.dec,
        };
    }

    toString() {
        return JSON.stringify(this);
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_coordcelestial_free(ptr);
    }
    /**
    * @returns {number}
    */
    get ra() {
        var ret = wasm.__wbg_get_coordcelestial_ra(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ra(arg0) {
        wasm.__wbg_set_coordcelestial_ra(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get dec() {
        var ret = wasm.__wbg_get_coordcelestial_dec(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set dec(arg0) {
        wasm.__wbg_set_coordcelestial_dec(this.ptr, arg0);
    }
}
/**
*/
export class Mtx2x2Js {

    toJSON() {
        return {
        };
    }

    toString() {
        return JSON.stringify(this);
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_mtx2x2js_free(ptr);
    }
}
/**
*/
export class Point2dJs {

    static __wrap(ptr) {
        const obj = Object.create(Point2dJs.prototype);
        obj.ptr = ptr;

        return obj;
    }

    toJSON() {
        return {
            x: this.x,
            y: this.y,
        };
    }

    toString() {
        return JSON.stringify(this);
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_point2djs_free(ptr);
    }
    /**
    * @returns {number}
    */
    get x() {
        var ret = wasm.__wbg_get_coordcelestial_ra(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set x(arg0) {
        wasm.__wbg_set_coordcelestial_ra(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get y() {
        var ret = wasm.__wbg_get_coordcelestial_dec(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set y(arg0) {
        wasm.__wbg_set_coordcelestial_dec(this.ptr, arg0);
    }
}
/**
*/
export class Point3dJs {

    static __wrap(ptr) {
        const obj = Object.create(Point3dJs.prototype);
        obj.ptr = ptr;

        return obj;
    }

    toJSON() {
        return {
            x: this.x,
            y: this.y,
            z: this.z,
        };
    }

    toString() {
        return JSON.stringify(this);
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_point3djs_free(ptr);
    }
    /**
    * @returns {number}
    */
    get x() {
        var ret = wasm.__wbg_get_point3djs_x(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set x(arg0) {
        wasm.__wbg_set_point3djs_x(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get y() {
        var ret = wasm.__wbg_get_point3djs_y(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set y(arg0) {
        wasm.__wbg_set_point3djs_y(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get z() {
        var ret = wasm.__wbg_get_point3djs_z(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set z(arg0) {
        wasm.__wbg_set_point3djs_z(this.ptr, arg0);
    }
}
/**
*/
export class WcsTan {

    static __wrap(ptr) {
        const obj = Object.create(WcsTan.prototype);
        obj.ptr = ptr;

        return obj;
    }

    toJSON() {
        return {
        };
    }

    toString() {
        return JSON.stringify(this);
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wcstan_free(ptr);
    }
    /**
    * @param {Point2dJs} crpix
    * @param {CoordCelestial} crval
    * @param {Mtx2x2Js} cd
    */
    constructor(crpix, crval, cd) {
        _assertClass(crpix, Point2dJs);
        var ptr0 = crpix.ptr;
        crpix.ptr = 0;
        _assertClass(crval, CoordCelestial);
        var ptr1 = crval.ptr;
        crval.ptr = 0;
        _assertClass(cd, Mtx2x2Js);
        var ptr2 = cd.ptr;
        cd.ptr = 0;
        var ret = wasm.wcstan_new(ptr0, ptr1, ptr2);
        return WcsTan.__wrap(ret);
    }
    /**
    * @param {Point3dJs} world
    * @returns {Point2dJs | undefined}
    */
    world_2_pix(world) {
        _assertClass(world, Point3dJs);
        var ptr0 = world.ptr;
        world.ptr = 0;
        var ret = wasm.wcstan_world_2_pix(this.ptr, ptr0);
        return ret === 0 ? undefined : Point2dJs.__wrap(ret);
    }
    /**
    * @param {Point3dJs} world
    * @returns {Point2dJs | undefined}
    */
    world_2_pix_no_sip(world) {
        _assertClass(world, Point3dJs);
        var ptr0 = world.ptr;
        world.ptr = 0;
        var ret = wasm.wcstan_world_2_pix_no_sip(this.ptr, ptr0);
        return ret === 0 ? undefined : Point2dJs.__wrap(ret);
    }
    /**
    * @param {Point2dJs} pix
    * @returns {Point3dJs}
    */
    pix_2_world(pix) {
        _assertClass(pix, Point2dJs);
        var ptr0 = pix.ptr;
        pix.ptr = 0;
        var ret = wasm.wcstan_pix_2_world(this.ptr, ptr0);
        return Point3dJs.__wrap(ret);
    }
}

export function __wbg_new_59cb74e423758ede() {
    var ret = new Error();
    return addHeapObject(ret);
};

export function __wbg_stack_558ba5917b466edd(arg0, arg1) {
    var ret = getObject(arg1).stack;
    var ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len0 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len0;
    getInt32Memory0()[arg0 / 4 + 0] = ptr0;
};

export function __wbg_error_4bb6c2a97407129a(arg0, arg1) {
    try {
        console.error(getStringFromWasm0(arg0, arg1));
    } finally {
        wasm.__wbindgen_free(arg0, arg1);
    }
};

export function __wbindgen_object_drop_ref(arg0) {
    takeObject(arg0);
};

export function __wbindgen_throw(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
};

