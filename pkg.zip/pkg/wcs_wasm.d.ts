/* tslint:disable */
/* eslint-disable */
/**
*/
export function set_panic_hook(): void;
/**
*/
export class CoordCelestial {
  free(): void;
/**
* @returns {number}
*/
  dec: number;
/**
* @returns {number}
*/
  ra: number;
}
/**
*/
export class Mtx2x2Js {
  free(): void;
}
/**
*/
export class Point2dJs {
  free(): void;
/**
* @returns {number}
*/
  x: number;
/**
* @returns {number}
*/
  y: number;
}
/**
*/
export class Point3dJs {
  free(): void;
/**
* @returns {number}
*/
  x: number;
/**
* @returns {number}
*/
  y: number;
/**
* @returns {number}
*/
  z: number;
}
/**
*/
export class WcsTan {
  free(): void;
/**
* @param {Point2dJs} crpix
* @param {CoordCelestial} crval
* @param {Mtx2x2Js} cd
*/
  constructor(crpix: Point2dJs, crval: CoordCelestial, cd: Mtx2x2Js);
/**
* @param {Point3dJs} world
* @returns {Point2dJs | undefined}
*/
  world_2_pix(world: Point3dJs): Point2dJs | undefined;
/**
* @param {Point3dJs} world
* @returns {Point2dJs | undefined}
*/
  world_2_pix_no_sip(world: Point3dJs): Point2dJs | undefined;
/**
* @param {Point2dJs} pix
* @returns {Point3dJs}
*/
  pix_2_world(pix: Point2dJs): Point3dJs;
}
