import * as wasm from "./wcs_wasm_bg.wasm";
export * from "./wcs_wasm_bg.js";